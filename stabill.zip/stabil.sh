clear
blue='\033[34;1m' 
green='\033[32;1m' 
purple='\033[35;1m' 
cyan='\033[36;1m' 
red='\033[31;1m' 
white='\033[37;1m' 
yellow='\033[33;1m' 
sleep 1
echo 
toilet -f big -f gay by Dhill•Benjamin•
echo $blue"Selamat Datang Gaes"
echo
sleep 2
echo $green"Silahkan Pilih Tools Nya:"
echo
echo $cyan"1.) Stabilkan Jaringan All Kartu"
echo
echo $red"0.) Keluar Aja!!!"
echo
echo $white
read -p "pilih mana:" bro

if [ $bro = 1 ] || [ $bro = 1 ]
then
clear
toilet -f big -F gay by Dhill•Benjamin•
echo $green"Stabilkan Jaringan By Dhill•Benjamin"
sleep 2
ping -s1000 1.1.1.1
fi

if [ $bro = 0 ] || [ $bro = 0 ]
then
clear
echo $yellow
figlet"Bye"
echo $white"To Be Continuied"
sleep 3
exit
fi

